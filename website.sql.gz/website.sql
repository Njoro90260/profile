-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2024 at 04:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) UNSIGNED NOT NULL,
  `person_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `person_address` text DEFAULT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `person_name`, `email`, `user_password`, `phone`, `person_address`, `profile_pic`, `reg_date`) VALUES
(1, 'Peter Njoroge', 'wchegesalome@gmail.com', '$2y$10$P1AFuUxcc9.8/wwKVQO6UOqwNg1Cb4mNkNBB.iMU2HszfqxeCkgea', '0713244359', '003, Thika', '?PNG\r\n\Z\n\0\0\0\rIHDR\0\0@\0\0?\0\0\0?M??\0\0\0gAMA\0\0???a\0\0\0sRGB\0???\0\0\0 cHRM\0\0z&\0\0??\0\0?\0\0\0??\0\0u0\0\0?`\0\0:?\0\0p??Q<\0\0\0	pHYs\0\0?\0\0??o?d\0\0\0bKGD\0?\0?\0?????\0\0\0tEXtEXIF:Orientation\01?X??\0\0?IIDATx^??y??u??+˻H\0?(????????#$????Wy?3?{q??????????_ĉ?????2?????_?', '2024-06-17 14:28:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
